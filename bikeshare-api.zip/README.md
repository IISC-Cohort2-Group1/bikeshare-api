# Create Virtual Environment
`python -m venv path of project .\venv`
# Activate Virtual Enviroment
`.\venv\Scripts\activate`